# Contributing to Eclipse Platform
See https://github.com/eclipse-platform/.github/blob/main/CONTRIBUTING.md
