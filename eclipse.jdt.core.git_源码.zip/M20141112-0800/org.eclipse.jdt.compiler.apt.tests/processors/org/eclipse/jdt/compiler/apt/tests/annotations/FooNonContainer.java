package org.eclipse.jdt.compiler.apt.tests.annotations;

public @interface FooNonContainer {
	Foo [] value();
}
