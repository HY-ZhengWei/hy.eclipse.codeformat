package question;  

   public @interface RTInvisibleAnno{  
   	String value(); 
   }