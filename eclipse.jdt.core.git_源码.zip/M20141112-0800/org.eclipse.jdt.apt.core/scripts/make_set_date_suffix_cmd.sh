
echo set DATE_SUFFIX=`date  +%Y%m%d-%H%M` > set_date_suffix.cmd
